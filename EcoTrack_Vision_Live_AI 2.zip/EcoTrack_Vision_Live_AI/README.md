# EcoTrack Vision — Live AI Detection (Hackathon Starter)

This project keeps the EcoTrack Vision dashboard and adds a Flask backend, real account registration/login, SQLite storage, image analysis through Roboflow Hosted Inference, and browser-camera frame scanning in authorised common areas.

## 1. Requirements
- Python 3.10+
- A Roboflow account and a trained/deployed object-detection model.
- Model classes should describe visible issues you actually trained for, for example `litter`, `overflowing_bin`, or `water_leak`. The model cannot detect a class it was not trained to recognise.
- Electricity usage cannot reliably be inferred from a normal camera image. Use meter/IoT data for real kWh readings; this app's readings form is for manually entering actual meter values.

## 2. Setup (Windows)
Open PowerShell in this folder:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
Copy-Item .env.example .env
```

Edit `.env` and set:
- `FLASK_SECRET_KEY` to a long random secret
- `ADMIN_SIGNUP_CODE` to a private admin signup code
- `ROBOFLOW_MODEL_ID` to your deployed model ID, such as `your-project/3`
- `ROBOFLOW_API_KEY` to your Roboflow private API key

Do not put the API key in `index.html`, GitHub, screenshots, or frontend JavaScript. Keep `.env` private and add it to `.gitignore`.

Then start the site:

```powershell
python app.py
```

Open http://127.0.0.1:5000 in your browser. Do not double-click `index.html`; the backend API needs to be running.

## 3. How to use
1. Sign Up with an email and password of at least 8 characters.
2. Log in.
3. Upload a photo to send it to the configured model, or choose an authorised common area and click **Start live camera**.
4. The browser captures a frame and sends it to `/api/detect`; matching detections are saved in SQLite and shown in Recent reports.
5. Maintenance/Admin accounts can change report status. Create an Admin account with the code from `.env`.

## 4. Real-world deployment notes
- Camera access generally requires `localhost` or HTTPS and browser permission.
- This is a hackathon starter, not a production security review. Add CSRF protection, rate limiting, stronger role/ownership policies, HTTPS, secure session settings, audit logging, and deployment configuration before public deployment.
- Use cameras only in authorised common areas with institutional approval and appropriate notices. Never use cameras in washrooms, changing rooms, or other private areas. Do not identify or track people.
- The AI output is a potential issue, not proof. A person should verify the alert before action.
- For campus-wide fixed cameras, an authorised local edge device/NVR integration is required; a browser webcam is only the camera attached to the user's device. This starter does not connect to existing CCTV automatically.
- Hosted inference sends captured images to the model provider. Check campus policy and provider terms before sending real campus footage.
- API/model errors are surfaced in the UI; no simulated detections are created.
